# Comparative-Analysis-of-Multiple-Alignment-Algorithms-for-the-Study-of-Multiple-Sequences-Alignments
Conducted a research case study of comparing and analyzing two of the most widely used Multiple Sequence Alignment algorithms 
(MUSCLE and CLUSTAL OMEGA) for the study of protein nucleotides.
The algorithms were examined and evaluated along the metrics of standard gold benchmark like PREFAB, 
OXBENCH, and time and space complexities.
