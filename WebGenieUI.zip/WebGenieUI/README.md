
  # WebGenie

  This is the codebase for the WebGenie project, the UI design is accessible on figma as shared. 

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  